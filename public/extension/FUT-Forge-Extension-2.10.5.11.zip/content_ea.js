// content_ea.js — isolated-world content script on the EA FC Ultimate Team Web App.
//
// Two independent jobs:
//   1. Club Sync presence beacon (unchanged) - tells background.js this tab exists.
//   2. Analytics bridge: inject.js (MAIN world) has no chrome.* access, so real feature usage
//      (SBC solver opened, Quick Complete started, Squad Builder used, Transfers/Settings opened)
//      it already signals via `document.dispatchEvent(new CustomEvent("futforge-message", ...))`
//      (its own existing sendToContent() helper) was never picked up by anything - nothing in the
//      isolated world was listening, so those signals went nowhere and background.js only ever
//      saw its own app_open/feature_error, never real in-app usage. This is the missing hop.
//
// SECURITY:
//   - inject.js runs in the EA page's own MAIN world - CustomEvents it dispatches on `document`
//     are page-controlled data, not a trusted source, exactly like reading page DOM content would
//     be. Nothing here trusts the *shape* of an incoming detail: every field is read
//     defensively (typeof-checked) and only a FIXED, hardcoded map decides whether a given
//     action/controller name translates to a canonical analytics event at all.
//   - The EA page can never make up a new event name: ACTION_EVENT_MAP and
//     NAVIGATION_FEATURE_MAP are closed lookups. An unrecognized action/controller is dropped,
//     not forwarded as "whatever the page called it".
//   - No page content is ever forwarded: only a fixed canonical event name and, for the two
//     feature_opened cases, a fixed allowlisted "feature" string chosen by this file - never a
//     value read out of the page's own event detail. Player names, club contents, EA tokens,
//     search terms are never read here at all, let alone forwarded.
//   - Debounced per signal so one user action can't fan out into a stream of duplicate events
//     (e.g. if the underlying navigation hook fires more than once for a single screen entry).

const ACTION_EVENT_MAP = {
  // sendToContent(action, ...) value (confirmed real call sites in inject.js) -> canonical event.
  // Quick Complete (single-slot and bulk) submits a solution for EA to auto-fill; sbc_submitted
  // already means exactly that in the existing taxonomy - not a new event.
  autoCompleteSBC: "sbc_submitted",
  autoCompleteSBCMulti: "sbc_submitted",
  // FUT Forge's own Squad Builder "generate" call.
  squadBuilder: "squad_builder_open",
};

const NAVIGATION_FEATURE_MAP = {
  // navigation controller class name (confirmed real strings in inject.js) -> canonical event
  // (+ a fixed "feature" label chosen here, never taken from the page).
  UTSBCHubViewController: { event: "sbc_solver_open" },
  UTTransferListViewController: { event: "feature_opened", feature: "transfers" },
  FutForgeSettingsViewController: { event: "feature_opened", feature: "settings" },
};

const DEBOUNCE_MS = 2000;
const lastForwardedAt = new Map();

function shouldForward(key, now) {
  const last = lastForwardedAt.get(key);
  if (last !== undefined && now - last < DEBOUNCE_MS) return false;
  lastForwardedAt.set(key, now);
  return true;
}

// Pure translation: page-controlled CustomEvent detail -> canonical {event, properties} or null.
// Never throws on a malformed/hostile detail; never returns anything not already hardcoded here.
function translateBridgeMessage(detail) {
  if (!detail || typeof detail !== "object") return null;
  // Structural marker check (defense in depth, not authentication - detail is page-controlled
  // data and this field is just as self-declared/spoofable as anything else in it): every real
  // sendToContent() call in inject.js sets source:"inject" and a numeric timestamp. A message
  // missing that shape isn't one of the real bridge calls this file was built to translate.
  if (detail.source !== "inject") return null;
  if (typeof detail.timestamp !== "number") return null;
  const action = typeof detail.action === "string" ? detail.action : null;
  if (!action) return null;

  if (action === "navigation") {
    const data = detail.data;
    if (!data || typeof data !== "object") return null;
    const controller = typeof data.controller === "string" ? data.controller : null;
    const navType = typeof data.type === "string" ? data.type : null;
    // Only entering a screen counts as "opened" - popping back out is not a second action.
    if (navType !== "push" || !controller) return null;
    const mapped = NAVIGATION_FEATURE_MAP[controller];
    if (!mapped) return null;
    return { event: mapped.event, properties: mapped.feature ? { feature: mapped.feature } : undefined, dedupeKey: "nav:" + controller };
  }

  const mappedEvent = ACTION_EVENT_MAP[action];
  if (!mappedEvent) return null;
  return { event: mappedEvent, properties: undefined, dedupeKey: "action:" + action };
}

function handleBridgeMessage(customEvent) {
  try {
    const translated = translateBridgeMessage(customEvent && customEvent.detail);
    if (!translated) return;
    if (!shouldForward(translated.dedupeKey, Date.now())) return;
    chrome.runtime.sendMessage({
      type: "FUT_FORGE_ANALYTICS_EVENT",
      event: translated.event,
      properties: translated.properties,
    });
  } catch (e) {
    // Extension context can be invalidated (e.g. reload during dev) - never let that surface as
    // a page-visible error, and never let a bridge failure affect the page itself.
  }
}

try {
  chrome.runtime.sendMessage({ type: "FUT_FORGE_EA_TAB_READY" });
} catch (e) {
  // Extension context can be invalidated (e.g. reload during dev) - never
  // let that surface as a page-visible error.
}

document.addEventListener("futforge-message", handleBridgeMessage);

// Exports exist only for tests to exercise the pure translation/debounce logic directly with a
// mocked chrome.runtime. Inert for the real content script: this file is loaded as a classic
// (non-module) script per manifest.json, so an unused top-level export has no runtime effect.
export { translateBridgeMessage, handleBridgeMessage, ACTION_EVENT_MAP, NAVIGATION_FEATURE_MAP, DEBOUNCE_MS };

// core_ready_wait.js — extension-authored readiness probe, MAIN world.
//
// Waits for the EA Web App's own runtime to have populated enough of
// window.services/window.repositories for the FUT Forge core (inject.js +
// futforge_auth.js, vendored unmodified in vendor/) to attach safely. This
// is NOT part of the shared core - it is host-specific glue, kept in its
// own tiny file on purpose so vendor/inject.js and vendor/futforge_auth.js
// never need to be wrapped or edited.
//
// Injected by background.js BEFORE vendor/inject.js and
// vendor/futforge_auth.js, via a separate chrome.scripting.executeScript
// call. Returns a plain {ready, waitedMs} result - no card/session/account
// data of any kind.
(async () => {
  const READY_TIMEOUT_MS = 15000;
  const READY_POLL_MS = 300;

  function isReady() {
    return !!(window.services && window.repositories);
  }

  const startedAt = Date.now();
  while (!isReady() && Date.now() - startedAt < READY_TIMEOUT_MS) {
    await new Promise((resolve) => setTimeout(resolve, READY_POLL_MS));
  }
  return { ready: isReady(), waitedMs: Date.now() - startedAt };
})();

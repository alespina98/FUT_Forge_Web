// background.js — MV3 service worker. Orchestrates two independent jobs on
// the EA FC Ultimate Team Web App tab:
//
//   1. Club Sync (Phase 1 of that separate track): find/open the EA Club
//      page, inject page_ea.js (MAIN world) to capture the club, then
//      (from Phase 3 onward) upload the result to the FUT Forge backend.
//      UNCHANGED by Milestone 1 - kept fully separate from core boot below.
//
//   2. Core boot (Milestone 1, browser extension track): once the EA tab is
//      ready, inject the REAL, unmodified FUT Forge core - vendor/inject.js
//      + vendor/futforge_auth.js (byte-identical copies of
//      futforge_core/inject.js + futforge_core/futforge_auth.js, kept in
//      sync by scripts/sync_core.mjs - see that file for why a copy exists
//      at all) plus vendor/futforge.css - into the page's MAIN world, so
//      the real FUT Forge hub/navbar UI renders on top of the EA Web App,
//      exactly as it already does inside FUT Forge Desktop
//      (window.py:227-254 does the equivalent injection via Qt WebEngine).
//
// State for both jobs is kept in chrome.storage.session (not module-level
// variables) because the service worker can be suspended and restarted
// between steps.
//
// SECURITY: this file never reads EA cookies or credentials. It only
// injects page_ea.js/vendor/*.js (none of which touch cookies/credentials
// either) and relays plain-data results.

const EA_CLUB_URL = "https://www.ea.com/ea-sports-fc/ultimate-team/web-app/";
const EA_URL_PATTERNS = [
  "https://www.ea.com/ea-sports-fc/ultimate-team/web-app/*",
  "https://www.ea.com/games/ea-sports-fc/ultimate-team/web-app/*",
  "https://www.ea.com/*/ea-sports-fc/ultimate-team/web-app/*",
  "https://www.ea.com/*/games/ea-sports-fc/ultimate-team/web-app/*",
];
const EA_TAB_LOAD_TIMEOUT_MS = 30000;

function isEaWebAppUrl(value) {
  try {
    const url = new URL(value);
    return url.protocol === "https:" && url.hostname === "www.ea.com" &&
      /^\/(?:[a-z]{2}-[a-z]{2}\/)?(?:games\/)?ea-sports-fc\/ultimate-team\/web-app\/?$/i.test(url.pathname);
  } catch (_) {
    return false;
  }
}

function log(stage, detail) {
  // Temporary, non-sensitive diagnostics for the Milestone 1 live test.
  // Never logs cookies/tokens/passwords/payloads - only stage names and
  // plain booleans/numbers/strings the user already knows (tab id, item
  // counts, error codes).
  if (detail !== undefined) {
    console.log(`[FUTFORGE-EXT] ${stage}`, detail);
  } else {
    console.log(`[FUTFORGE-EXT] ${stage}`);
  }
}

async function getActiveSync() {
  const stored = await chrome.storage.session.get("activeSync");
  return stored.activeSync || null;
}

async function setActiveSync(value) {
  if (value === null) {
    await chrome.storage.session.remove("activeSync");
  } else {
    await chrome.storage.session.set({ activeSync: value });
  }
}

function reportStatus(webTabId, detail) {
  if (!webTabId) return;
  chrome.tabs.sendMessage(webTabId, { type: "SYNC_STATUS", detail }).catch(() => {
    // Web tab may have navigated away/closed - nothing to recover here.
  });
}

async function findOrOpenEaTab() {
  const existing = await chrome.tabs.query({ url: EA_URL_PATTERNS });
  if (existing.length > 0) {
    const tab = existing[0];
    await chrome.tabs.update(tab.id, { active: true });
    if (tab.windowId != null) {
      await chrome.windows.update(tab.windowId, { focused: true });
    }
    return { tab, opened: false };
  }
  const tab = await chrome.tabs.create({ url: EA_CLUB_URL, active: true });
  return { tab, opened: true };
}

function waitForTabComplete(tabId, timeoutMs) {
  return new Promise((resolve) => {
    let done = false;
    const finish = (ok) => {
      if (done) return;
      done = true;
      chrome.tabs.onUpdated.removeListener(listener);
      resolve(ok);
    };
    const listener = (updatedTabId, changeInfo) => {
      if (updatedTabId === tabId && changeInfo.status === "complete") finish(true);
    };
    chrome.tabs.onUpdated.addListener(listener);
    chrome.tabs.get(tabId).then((tab) => {
      if (tab.status === "complete") finish(true);
    }).catch(() => finish(false));
    setTimeout(() => finish(false), timeoutMs);
  });
}

async function captureClub(eaTabId) {
  const results = await chrome.scripting.executeScript({
    target: { tabId: eaTabId },
    world: "MAIN",
    files: ["page_ea.js"],
  });
  const first = results && results[0];
  return (first && first.result) || { ok: false, error: "no_result_from_page_script" };
}

async function runClubSync(webTabId, syncSessionId) {
  await setActiveSync({ syncSessionId, webTabId, status: "connecting", startedAt: Date.now() });
  reportStatus(webTabId, { status: "connecting", message: "Connessione alla EA Web App..." });

  let eaTab;
  try {
    const found = await findOrOpenEaTab();
    eaTab = found.tab;
    if (found.opened) {
      await waitForTabComplete(eaTab.id, EA_TAB_LOAD_TIMEOUT_MS);
    }
  } catch (e) {
    reportStatus(webTabId, { status: "error", error: "ea_tab_unavailable" });
    await setActiveSync(null);
    return;
  }

  await setActiveSync({ syncSessionId, webTabId, eaTabId: eaTab.id, status: "capturing", startedAt: Date.now() });
  reportStatus(webTabId, { status: "capturing", message: "Sincronizzazione del club..." });

  let capture;
  try {
    capture = await captureClub(eaTab.id);
  } catch (e) {
    reportStatus(webTabId, { status: "error", error: "capture_failed" });
    await setActiveSync(null);
    return;
  }

  if (!capture.ok) {
    reportStatus(webTabId, { status: "error", error: capture.error || "capture_failed" });
    await setActiveSync(null);
    return;
  }

  // Phase 1: report the captured count only, no upload yet. Phase 3 extends
  // this branch to POST { syncSessionId, items: capture.items } to the FUT
  // Forge backend and report the server's item_count instead.
  reportStatus(webTabId, { status: "captured", itemCount: capture.items.length });
  await setActiveSync(null);
}

// ---------------------------------------------------------------------
// Core boot (Milestone 1) - completely independent of Club Sync above.
// ---------------------------------------------------------------------

// Order matters: futforge_auth.js reads window.FutForgeDispatcher, which
// inject.js defines. futforge_auth.js tolerates the reverse order too (it
// polls for FutForgeDispatcher up to 10s before giving up), but injecting
// inject.js first matches how Desktop injects into an already-open tab
// (window.py:254) and avoids that polling wait in the common case.
const CORE_JS_FILES = ["vendor/inject.js", "vendor/futforge_auth.js", "vendor/announcements.js"];
const CORE_CSS_FILE = "vendor/futforge.css";

// ---------------------------------------------------------------------
// Host bootstrap data (Milestone 2) - grade/chemistry-style config +
// price feed. Same globalThis.__FUTFORGE_PRICE_DATA__ / localStorage
// contract Desktop bootstraps (window.py:233-249), populated here instead
// because this host is a browser extension, not Qt WebEngine. The core
// (futforge_auth.js) only ever reads these three values - it has no idea
// FUT.GG or a bundled JSON file is behind them, and never will: that
// knowledge stays entirely in this file (the "adapter"), same principle as
// the vendor/ core files never knowing they're running inside an
// extension instead of Desktop.
// ---------------------------------------------------------------------

const FUTGG_BASE = "https://r2.fut.gg";
const FUTGG_GAME = "26";
const FUTGG_INDEX_KEY = "player-prices-index";
const FUTGG_PRICE_KEY = "player-prices-ps5-dyn";
const FUTGG_FETCH_TIMEOUT_MS = 10000;
const PRICE_CACHE_TTL_MS = 5 * 60 * 1000; // matches futforge_backend's PRICING_CACHE_TTL_SECONDS

let priceCache = { at: 0, data: null };
let priceFetchInFlight = null;
let gradeConfigCache = null;
let chemStyleConfigCache = null;

// Test-only: Node's ES module cache means tests/price_feed.test.mjs's
// repeated imports of this file share the same module-scope cache state
// above - this resets it between test cases. No caller in the real
// extension ever uses this.
function _resetPriceCacheForTests() {
  priceCache = { at: 0, data: null };
  priceFetchInFlight = null;
}

// ---------------------------------------------------------------------
// Analytics (fire-and-forget, never blocks core boot). MV3 service workers
// have no localStorage/sessionStorage, so install_id lives in
// chrome.storage.local (persists across worker restarts); session_id is a
// module-scope UUID, regenerated whenever the worker is respawned - close
// enough to "session" for a background context that has no page lifetime.
// ---------------------------------------------------------------------

const ANALYTICS_ENDPOINT = "https://futforgeofficial.com/api/analytics/events";
const ANALYTICS_TIMEOUT_MS = 3000;
let extensionSessionId = null;

// Canonical events/feature labels the MAIN-world usage bridge (content_ea.js) is allowed to
// relay - must exactly match what content_ea.js's own ACTION_EVENT_MAP/NAVIGATION_FEATURE_MAP/SBC
// submit-outcome tracker can produce. A second, independent check (not a duplicate of
// content_ea.js's own validation) so this listener never trusts a message's shape just because of
// where it came from.
const ANALYTICS_BRIDGE_EVENTS = new Set([
  "sbc_solver_open", "sbc_quick_complete_started", "sbc_submitted", "sbc_group_completed",
  "squad_builder_open", "feature_opened", "feature_error",
]);
const ANALYTICS_BRIDGE_FEATURES = new Set(["transfers", "settings", "sbc_submit"]);
// count means "real completed/failed units for this one event" - only meaningful, and only
// accepted, on the events content_ea.js's SBC submit-outcome tracker actually produces it for.
// Mirrors COUNT_ELIGIBLE_EVENTS/MAX_REASONABLE_COUNT in futforge-web's events.ts - kept as an
// independent literal here rather than imported, matching this file's existing choice to
// re-validate rather than trust content_ea.js's own checks.
const ANALYTICS_BRIDGE_COUNT_EVENTS = new Set(["sbc_submitted", "feature_error"]);
const ANALYTICS_MAX_REASONABLE_COUNT = 500;

async function getInstallId() {
  const stored = await chrome.storage.local.get("installId");
  if (stored.installId) return stored.installId;
  const id = crypto.randomUUID();
  await chrome.storage.local.set({ installId: id });
  return id;
}

function getExtensionSessionId() {
  if (!extensionSessionId) extensionSessionId = crypto.randomUUID();
  return extensionSessionId;
}

async function trackEvent(event, properties, eventId) {
  try {
    const installId = await getInstallId();
    const body = JSON.stringify({
      events: [{
        event,
        // A caller-supplied, deterministic id (content_ea.js derives one per SBC operation) makes
        // a retried/duplicated send of the SAME operation a no-op server-side (INSERT OR IGNORE on
        // this column) instead of a double-counted row - real retry/idempotency protection, not
        // just the client-side dedup content_ea.js already does before this is ever called.
        event_id: typeof eventId === "string" && eventId ? eventId : crypto.randomUUID(),
        event_version: 1,
        timestamp: Date.now(),
        client_type: "chrome_extension",
        client_version: chrome.runtime.getManifest().version,
        install_id: installId,
        session_id: getExtensionSessionId(),
        properties: properties || {},
      }],
    });
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), ANALYTICS_TIMEOUT_MS);
    try {
      await fetch(ANALYTICS_ENDPOINT, {
        method: "POST",
        mode: "cors",
        credentials: "omit",
        keepalive: true,
        headers: { "Content-Type": "application/json" },
        body,
        signal: controller.signal,
      });
    } finally {
      clearTimeout(timer);
    }
  } catch (e) {
    log("analytics send failed (non-blocking)", { event, error: String((e && e.message) || e) });
  }
}

async function fetchJsonWithTimeout(url, timeoutMs) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, { signal: controller.signal, headers: { Accept: "application/json" } });
    if (!res.ok) throw new Error(`http_${res.status}`);
    return await res.json();
  } finally {
    clearTimeout(timer);
  }
}

// Semantically the same two-request manifest+blob fetch as
// futforge_shared/pricing.py:fetch_futgg_price_data() (same base URL, same
// manifest keys, same {idx, blob} shape and length-mismatch validation) -
// not a reimplementation of the delta-decode math, which stays entirely in
// futforge_auth.js (ffFutggMarketValue/ffFetchMidasPrices) exactly as it
// already runs for Desktop.
async function fetchFutggPriceDataUncached() {
  const manifest = await fetchJsonWithTimeout(`${FUTGG_BASE}/${FUTGG_GAME}/manifest.json`, FUTGG_FETCH_TIMEOUT_MS);
  const ver = manifest && manifest._version;
  const ih = manifest && manifest[FUTGG_INDEX_KEY];
  const ph = manifest && manifest[FUTGG_PRICE_KEY];
  if (ver === undefined || ver === null || !ih || !ph) {
    throw new Error("futgg_manifest_missing_price_assets");
  }
  const indexUrl = `${FUTGG_BASE}/${FUTGG_GAME}/${FUTGG_INDEX_KEY}.v${ver}.${ih}.json`;
  const priceUrl = `${FUTGG_BASE}/${FUTGG_GAME}/${FUTGG_PRICE_KEY}.v${ver}.${ph}.json`;
  const [idx, blob] = await Promise.all([
    fetchJsonWithTimeout(indexUrl, FUTGG_FETCH_TIMEOUT_MS),
    fetchJsonWithTimeout(priceUrl, FUTGG_FETCH_TIMEOUT_MS),
  ]);
  const deltas = idx && Array.isArray(idx.d) ? idx.d : null;
  const prices = blob && Array.isArray(blob.p) ? blob.p : null;
  if (!deltas || !prices || prices.length !== deltas.length + 1) {
    throw new Error("futgg_price_index_mismatch");
  }
  return { idx, blob, indexUrl, priceUrl, manifestVersion: ver };
}

// Best-effort and never throws: any failure (network, timeout, malformed
// response) resolves to null, the same fallback Desktop uses when
// fetch_futgg_price_data() raises (window.py:247-249). Cached for
// PRICE_CACHE_TTL_MS and de-duplicated via priceFetchInFlight so opening
// several EA tabs (or a quick reload) doesn't re-fetch ~27k price entries
// more than once per cache window.
async function getPriceData() {
  const now = Date.now();
  if (priceCache.data && now - priceCache.at < PRICE_CACHE_TTL_MS) {
    log("price cache hit", { ageMs: now - priceCache.at });
    return priceCache.data;
  }
  if (priceFetchInFlight) return priceFetchInFlight;
  priceFetchInFlight = (async () => {
    try {
      const data = await fetchFutggPriceDataUncached();
      priceCache = { at: Date.now(), data };
      log("price fetch ok", { priceCount: (data.idx.d || []).length + 1, manifestVersion: data.manifestVersion });
      return data;
    } catch (e) {
      log("price fetch failed (non-blocking)", { error: String((e && e.message) || e) });
      return null;
    } finally {
      priceFetchInFlight = null;
    }
  })();
  return priceFetchInFlight;
}

// grade_config_v1.json / chem_style_config_v1.json are static files bundled
// into the extension package (see scripts/sync_core.mjs) - no network
// involved, so unlike price data there is nothing to time out or retry.
// Cached in module scope for this service worker's lifetime only.
async function loadBundledJson(relativePath) {
  try {
    const res = await fetch(chrome.runtime.getURL(relativePath));
    return await res.json();
  } catch (e) {
    log("bundled config load failed", { relativePath, error: String((e && e.message) || e) });
    return null;
  }
}
async function getGradeConfig() {
  if (gradeConfigCache === null) gradeConfigCache = await loadBundledJson("vendor/grade_config_v1.json");
  return gradeConfigCache;
}
async function getChemStyleConfig() {
  if (chemStyleConfigCache === null) chemStyleConfigCache = await loadBundledJson("vendor/chem_style_config_v1.json");
  return chemStyleConfigCache;
}

// Injected functions run in the EA page's MAIN world with no closure over
// this file's scope (chrome.scripting serializes the function body) - they
// only ever write the same three values Desktop's grade_boot/chem_style_boot/
// price_boot bootstrap scripts write, nothing else, and expose no callable
// API back to the page.
function setHostBootstrapData(gradeConfig, chemStyleConfig, clientIdentity) {
  try {
    if (gradeConfig) localStorage.setItem("futforge_grade_config_v1", JSON.stringify(gradeConfig));
  } catch (_) {}
  try {
    if (chemStyleConfig) localStorage.setItem("futforge_chem_style_config_v1", JSON.stringify(chemStyleConfig));
  } catch (_) {}
  // Guarantee the contract always exists (never undefined) even before the
  // async price fetch below resolves - same guarantee Desktop's price_boot
  // gives (globalThis.__FUTFORGE_PRICE_DATA__=null on failure).
  if (!("__FUTFORGE_PRICE_DATA__" in globalThis)) globalThis.__FUTFORGE_PRICE_DATA__ = null;
  if (clientIdentity && clientIdentity.platform === "extension" && typeof clientIdentity.version === "string") {
    globalThis.__FUTFORGE_CLIENT__ = { platform: "extension", version: clientIdentity.version };
  }
}
function setPriceData(priceData) {
  globalThis.__FUTFORGE_PRICE_DATA__ = priceData || null;
}

function coreBootKey(tabId) {
  return `coreBoot:${tabId}`;
}

async function getCoreBootState(tabId) {
  const stored = await chrome.storage.session.get(coreBootKey(tabId));
  return stored[coreBootKey(tabId)] || null;
}

async function setCoreBootState(tabId, state) {
  if (state === null) {
    await chrome.storage.session.remove(coreBootKey(tabId));
  } else {
    await chrome.storage.session.set({ [coreBootKey(tabId)]: state });
  }
}

async function bootCoreIfNeeded(tab) {
  const tabId = tab && tab.id;
  if (!tabId) return;
  // Guard: only ever boot into a real EA Club Web App tab, even though the
  // only caller today (content_ea.js) is itself scoped to that URL by the
  // manifest - defense in depth, not load-bearing.
  if (!tab.url || !isEaWebAppUrl(tab.url)) return;

  const existing = await getCoreBootState(tabId);
  if (existing === "booting" || existing === "done") {
    log("duplicate injection skipped", { tabId, existing });
    return;
  }

  await setCoreBootState(tabId, "booting");

  try {
    const waitResults = await chrome.scripting.executeScript({
      target: { tabId },
      world: "MAIN",
      files: ["core_ready_wait.js"],
    });
    const wait = (waitResults && waitResults[0] && waitResults[0].result) || { ready: false, waitedMs: 0 };
    if (!wait.ready) {
      log("error stage: ea_runtime_not_ready", { tabId, waitedMs: wait.waitedMs });
      await setCoreBootState(tabId, null); // allow retry on next navigation/reload
      return;
    }
    log("EA runtime ready", { tabId, waitedMs: wait.waitedMs });

    await chrome.scripting.insertCSS({ target: { tabId }, files: [CORE_CSS_FILE] });

    // Grade/chemistry-style config (local, no network) must land before the
    // core reads them, so this is awaited like CSS. Price data is
    // deliberately NOT awaited here: fetching ~27k FUT.GG price entries over
    // the network must never delay the hub/navbar/SBC UI from appearing,
    // and must never get stuck if FUT.GG is unreachable. It resolves in the
    // background and overwrites the same MAIN-world global a moment later
    // via setPriceData - safe because futforge_auth.js re-reads
    // globalThis.__FUTFORGE_PRICE_DATA__ on every price lookup call rather
    // than caching it once at load time.
    const [gradeConfig, chemStyleConfig] = await Promise.all([getGradeConfig(), getChemStyleConfig()]);
    const clientIdentity = { platform: "extension", version: chrome.runtime.getManifest().version };
    await chrome.scripting.executeScript({
      target: { tabId },
      world: "MAIN",
      func: setHostBootstrapData,
      args: [gradeConfig, chemStyleConfig, clientIdentity],
    });
    log("grade/chem-style config bootstrapped", { tabId, hasGrade: !!gradeConfig, hasChemStyle: !!chemStyleConfig });

    getPriceData().then(async (priceData) => {
      try {
        await chrome.scripting.executeScript({
          target: { tabId },
          world: "MAIN",
          func: setPriceData,
          args: [priceData],
        });
        log("price data available in MAIN world", { tabId, available: !!priceData });
      } catch (e) {
        // Tab likely navigated/closed before the background fetch resolved
        // - not a boot failure, nothing to reset.
        log("price data injection skipped", { tabId, error: String((e && e.message) || e) });
      }
    });

    // Two files, one call: chrome.scripting guarantees in-order execution
    // for files listed in a single executeScript call.
    await chrome.scripting.executeScript({
      target: { tabId },
      world: "MAIN",
      files: CORE_JS_FILES,
    });
    log("futforge_auth injected", { tabId });
    log("inject.js injected", { tabId });

    await setCoreBootState(tabId, "done");
    log("core boot complete", { tabId });
    trackEvent("app_open", { feature: "core_boot" });
  } catch (e) {
    log("error stage: injection_failed", { tabId, error: String((e && e.message) || e) });
    await setCoreBootState(tabId, null); // allow retry on next navigation/reload
    trackEvent("feature_error", { feature: "core_boot", message: String((e && e.message) || e) });
  }
}

// A genuine navigation/reload of the EA tab must re-boot the core (that's
// correct behavior, not duplication) - clear the marker so the next
// FUT_FORGE_EA_TAB_READY beacon from the freshly-loaded page is treated as
// a new boot, not a duplicate of a stale one.
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status === "loading") {
    setCoreBootState(tabId, null);
  }
});
chrome.tabs.onRemoved.addListener((tabId) => {
  setCoreBootState(tabId, null);
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || typeof message.type !== "string") return;

  if (message.type === "FUT_FORGE_EA_TAB_READY") {
    if (sender.tab) bootCoreIfNeeded(sender.tab);
    return;
  }

  if (message.type === "FUT_FORGE_ANALYTICS_EVENT") {
    // Defense in depth: content_ea.js already only forwards messages it translated/aggregated via
    // its own fixed lookup and SBC submit-outcome tracker, but this listener re-validates
    // independently rather than trusting any sender (this repo's own content script or otherwise)
    // to have done that correctly.
    if (!ANALYTICS_BRIDGE_EVENTS.has(message.event)) return;
    let properties;
    if (message.properties !== undefined) {
      if (typeof message.properties !== "object" || message.properties === null) return;
      const keys = Object.keys(message.properties);
      if (keys.length > 2) return;
      for (const key of keys) {
        if (key !== "feature" && key !== "count") return;
      }
      if (keys.includes("feature") && !ANALYTICS_BRIDGE_FEATURES.has(message.properties.feature)) return;
      if (keys.includes("count")) {
        const value = message.properties.count;
        if (!ANALYTICS_BRIDGE_COUNT_EVENTS.has(message.event)) return;
        if (!Number.isInteger(value) || value < 1 || value > ANALYTICS_MAX_REASONABLE_COUNT) return;
      }
      properties = message.properties;
    }
    const eventId = typeof message.eventId === "string" ? message.eventId : undefined;
    trackEvent(message.event, properties, eventId);
    return;
  }

  if (message.type === "START_CLUB_SYNC") {
    const webTabId = sender.tab && sender.tab.id;
    const syncSessionId = message.syncSessionId;
    if (!webTabId || !syncSessionId) {
      sendResponse({ ok: false, error: "invalid_request" });
      return;
    }
    sendResponse({ ok: true });
    runClubSync(webTabId, syncSessionId);
    return;
  }

  if (message.type === "PING_FROM_POPUP") {
    // Dev-only: lets popup.js trigger a capture without the full web page
    // handshake, for the Phase 1 manual test. See popup.js.
    (async () => {
      const found = await chrome.tabs.query({ url: EA_URL_PATTERNS });
      if (found.length === 0) {
        sendResponse({ ok: false, error: "no_ea_tab_open" });
        return;
      }
      try {
        const capture = await captureClub(found[0].id);
        sendResponse(capture);
      } catch (e) {
        sendResponse({ ok: false, error: String((e && e.message) || e) });
      }
    })();
    return true; // keep sendResponse alive for the async branch above
  }
});

// Exports exist only for tests/price_feed.test.mjs to exercise the pure
// fetch/parse/cache logic directly with a mocked fetch(). Inert for the
// real extension: this is a "type":"module" service worker per
// manifest.json, and an unused top-level export has no runtime effect.
export {
  fetchJsonWithTimeout,
  fetchFutggPriceDataUncached,
  getPriceData,
  loadBundledJson,
  setHostBootstrapData,
  setPriceData,
  _resetPriceCacheForTests,
  trackEvent,
};

const EA_WEB_APP_URL = "https://www.ea.com/ea-sports-fc/ultimate-team/web-app/";
const EA_URL_PATTERNS = [
  "https://www.ea.com/ea-sports-fc/ultimate-team/web-app/*",
  "https://www.ea.com/games/ea-sports-fc/ultimate-team/web-app/*",
  "https://www.ea.com/*/ea-sports-fc/ultimate-team/web-app/*",
  "https://www.ea.com/*/games/ea-sports-fc/ultimate-team/web-app/*",
];

const status = document.getElementById("status");
const openButton = document.getElementById("open-ea");

chrome.tabs.query({ url: EA_URL_PATTERNS }, (tabs) => {
  if (chrome.runtime.lastError) {
    status.textContent = "Open the EA Web App to start FUT Forge.";
    return;
  }
  if (tabs.length > 0) {
    status.textContent = "EA Web App detected. FUT Forge activates there automatically.";
    openButton.textContent = "Go to EA Web App";
    openButton.dataset.tabId = String(tabs[0].id);
    openButton.dataset.windowId = String(tabs[0].windowId);
  } else {
    status.textContent = "EA Web App is not open yet.";
  }
});

openButton.addEventListener("click", async () => {
  const tabId = Number(openButton.dataset.tabId);
  const windowId = Number(openButton.dataset.windowId);
  if (Number.isInteger(tabId)) {
    await chrome.tabs.update(tabId, { active: true });
    if (Number.isInteger(windowId)) await chrome.windows.update(windowId, { focused: true });
  } else {
    await chrome.tabs.create({ url: EA_WEB_APP_URL, active: true });
  }
  window.close();
});

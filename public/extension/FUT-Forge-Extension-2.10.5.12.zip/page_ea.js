// page_ea.js — MAIN-world capture script for the EA FC Ultimate Team Web App.
//
// Ported near-verbatim from FUT_Forge/devtools_capture.py's
// request_club_on_demand() (the same expression Desktop's Club Sync already
// sends over CDP). Only difference from the Desktop version: a bounded
// readiness wait loop, because an extension has no equivalent of Desktop's
// native_bridge_ready flag / 1.2s post-load delay to know when EA's own
// services are up.
//
// Injected by background.js via chrome.scripting.executeScript({world:"MAIN"}).
// Runs directly in the EA page's own JS context, using window.services.Club
// exactly like the EA Web App's own UI does to render the Club screen.
//
// SECURITY: this script never reads document.cookie, localStorage, EA
// session/auth tokens, or any EA identity data. It calls the same read-only
// search method the page's own Club UI calls, and only extracts the plain
// card fields already extracted by Desktop's Club Sync (id, resourceId,
// assetId, rating, rarityId, untradeable, lastSalePrice, name). No network
// request is made from this file - it only returns data to the caller
// (background.js), which decides what happens to it.
//
// TEMPORARY DIAGNOSTIC (Phase 1 live-capture investigation) - the `debug`
// field on the returned object is non-sensitive by construction: only
// booleans, counts, timings, and top-level object *key names* (never
// values/card data/tokens). It lets the caller tell PASS (items>0) apart
// from EMPTY (search genuinely returned nothing) apart from a silent
// failure earlier in the pipeline that previously looked identical to
// EMPTY. Remove once the real-browser capture is confirmed reliable.
(async () => {
  const READY_TIMEOUT_MS = 15000;
  const READY_POLL_MS = 300;
  const debug = { stage: "init" };

  function isReady() {
    return !!(
      window.services && services.Club && typeof services.Club.search === "function" &&
      window.UTSearchCriteriaDTO && window.SearchType
    );
  }

  debug.stage = "waiting_for_ready";
  const startedAt = Date.now();
  while (!isReady() && Date.now() - startedAt < READY_TIMEOUT_MS) {
    await new Promise((resolve) => setTimeout(resolve, READY_POLL_MS));
  }
  debug.readyWaitedMs = Date.now() - startedAt;

  try {
    if (!isReady()) {
      debug.stage = "not_ready_after_timeout";
      return { ok: false, error: "club-service-not-ready", debug };
    }
    debug.stage = "ready";

    // services.Club.search() returns an Observable, not a Promise - same
    // adapter Desktop uses to bridge it into an awaitable value.
    const obsToPromise = (obs) =>
      new Promise((resolve) => {
        try {
          if (!obs || typeof obs.observe !== "function") {
            debug.observeIsFunction = false;
            return resolve(null);
          }
          debug.observeIsFunction = true;
          const ctx = {};
          obs.observe(ctx, function (o, r) {
            debug.observeCallbackFired = true;
            debug.rawResponseType = typeof r;
            debug.rawResponseKeys = r && typeof r === "object" ? Object.keys(r) : null;
            if (r && typeof r === "object") {
              debug.responseSuccess = "success" in r ? !!r.success : null;
              debug.responseStatus = "status" in r ? r.status : null;
              // r.error is EA's own short technical error code/object for the
              // failed call (e.g. an auth/session status), never card data or
              // credentials - safe to surface, capped defensively in size.
              if ("error" in r && r.error != null) {
                try {
                  const serialized = typeof r.error === "string" ? r.error : JSON.stringify(r.error);
                  debug.responseError = serialized.slice(0, 300);
                } catch (e) {
                  debug.responseError = "(unserializable error value)";
                }
              }
              debug.responseRetryAfter = "retryAfter" in r ? r.retryAfter : null;
              debug.hasResponseObject = !!r.response;
              debug.responseObjectKeys = r.response && typeof r.response === "object" ? Object.keys(r.response) : null;
              debug.responseItemsIsArray = !!(r.response && Array.isArray(r.response.items));
              debug.hasItemDataArray = Array.isArray(r.itemData);
            }
            try {
              o.unobserve && o.unobserve(ctx);
            } catch (e) {}
            resolve(r || null);
          });
        } catch (e) {
          debug.observeThrew = String((e && e.message) || e);
          resolve(null);
        }
      });

    // NOTE (verified live, see FUT_Forge audit): services.Club.search()
    // ignores offset/start/count and always returns the full club in one
    // response - a paging loop would only re-fetch and re-accumulate the
    // same items on every iteration. One call plus id-based dedup below is
    // the correct, current contract - matches devtools_capture.py exactly.
    const c = new UTSearchCriteriaDTO();
    c.type = SearchType.PLAYER != null ? SearchType.PLAYER : 0;
    c.offset = 0;
    c.start = 0;
    c.count = 5000;
    debug.stage = "calling_search";
    debug.searchReturnType = typeof services.Club.search;
    const observable = services.Club.search(c);
    debug.searchReturnedFalsy = !observable;
    debug.stage = "awaiting_observe";
    const r = await obsToPromise(observable);
    debug.stage = "observe_settled";

    // EA can answer with a well-formed response envelope that still carries
    // response.items = [] (an empty-but-valid array) while explicitly
    // signalling failure via success:false / a non-2xx status (e.g. a 403
    // when the session/entitlement check rejects the call). Treating that as
    // "0 items" would silently misreport a real EA-side error as an empty
    // club - it must surface as FAIL, not EMPTY.
    if (r && typeof r === "object" && "success" in r && r.success === false) {
      debug.stage = "ea_api_error";
      const statusPart = debug.responseStatus != null ? String(debug.responseStatus) : "unknown";
      return { ok: false, error: "ea_api_error:" + statusPart, debug };
    }

    const a =
      r && r.response && Array.isArray(r.response.items)
        ? r.response.items
        : r && Array.isArray(r.itemData)
          ? r.itemData
          : [];
    debug.rawItemCountBeforeDedup = a.length;

    const seen = new Set();
    const out = [];
    for (const it of a) {
      if (!it) continue;
      const id = Number(it.id || it.itemId || 0);
      if (seen.has(id)) continue;
      seen.add(id);
      // Evolved items carry no top-level name/playerName/displayName -
      // the real identity lives in the entity's own static data.
      const sd = (typeof it.getStaticData === "function" ? it.getStaticData() : it._staticData) || {};
      const resolvedName =
        it.name ||
        it.playerName ||
        it.displayName ||
        it.commonName ||
        sd.knownAs ||
        sd.name ||
        [sd.firstName, sd.lastName].filter(Boolean).join(" ") ||
        "";
      out.push({
        id: id,
        definitionId: Number(it.definitionId || it.definitionid || 0),
        resourceId: Number(it.resourceId || it.resourceID || it.definitionId || 0),
        assetId: Number(it.assetId || 0),
        rating: Number(it.rating || it._rating || 0),
        rarityId: Number(it.rarityId || it.rarityID || 0),
        untradeable: !!(it.untradeable || it._untradeable),
        lastSalePrice: Number(it.lastSalePrice || 0),
        name: String(resolvedName),
      });
    }
    debug.stage = "done";
    return { ok: true, items: out, debug };
  } catch (e) {
    debug.stage = "exception:" + debug.stage;
    return { ok: false, error: String((e && e.message) || e), debug };
  }
})();

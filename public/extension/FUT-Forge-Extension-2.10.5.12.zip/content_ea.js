// content_ea.js — isolated-world content script on the EA FC Ultimate Team Web App.
//
// Two independent jobs:
//   1. Club Sync presence beacon (unchanged) - tells background.js this tab exists.
//   2. Analytics bridge: inject.js (MAIN world) has no chrome.* access, so real feature usage
//      (SBC solver opened, Quick Complete started, Squad Builder used, Transfers/Settings opened,
//      real per-challenge SBC submission outcomes) it already signals via
//      `document.dispatchEvent(new CustomEvent("futforge-message", ...))` (its own existing
//      sendToContent()/sendDebug() helpers) was never picked up by anything - nothing in the
//      isolated world was listening, so those signals went nowhere and background.js only ever
//      saw its own app_open/feature_error, never real in-app usage. This is the missing hop.
//
// SECURITY:
//   - inject.js runs in the EA page's own MAIN world - CustomEvents it dispatches on `document`
//     are page-controlled data, not a trusted source, exactly like reading page DOM content would
//     be. Nothing here trusts the *shape* of an incoming detail: every field is read
//     defensively (typeof-checked) and only a FIXED, hardcoded map/regex set decides whether a
//     given action/controller/debug-message translates to a canonical analytics event at all.
//   - The EA page can never make up a new event name: ACTION_EVENT_MAP and
//     NAVIGATION_FEATURE_MAP are closed lookups, and the SBC submit-outcome parser below only
//     recognizes two specific, fixed message shapes. An unrecognized action/controller/message is
//     dropped, not forwarded as "whatever the page called it".
//   - No page content is ever forwarded: only a fixed canonical event name and, for the two
//     feature_opened cases, a fixed allowlisted "feature" string chosen by this file, and for SBC
//     submit outcomes a numeric count derived from counting real per-challenge signals - never a
//     value read out of the page's own event detail. Player names, club contents, EA tokens,
//     search terms, SBC/challenge names are never read here at all, let alone forwarded.
//   - Debounced per signal so one user action can't fan out into a stream of duplicate events
//     (e.g. if the underlying navigation hook fires more than once for a single screen entry).

const ACTION_EVENT_MAP = {
  // sendToContent(action, ...) value (confirmed real call sites in inject.js) -> canonical event.
  // FUT Forge's own Squad Builder "generate" call.
  squadBuilder: "squad_builder_open",
};

const NAVIGATION_FEATURE_MAP = {
  // navigation controller class name (confirmed real strings in inject.js) -> canonical event
  // (+ a fixed "feature" label chosen here, never taken from the page).
  UTSBCHubViewController: { event: "sbc_solver_open" },
  UTTransferListViewController: { event: "feature_opened", feature: "transfers" },
  FutForgeSettingsViewController: { event: "feature_opened", feature: "settings" },
};

const DEBOUNCE_MS = 2000;
const lastForwardedAt = new Map();

function shouldForward(key, now) {
  const last = lastForwardedAt.get(key);
  if (last !== undefined && now - last < DEBOUNCE_MS) return false;
  lastForwardedAt.set(key, now);
  return true;
}

// Structural marker check (defense in depth, not authentication - detail is page-controlled data
// and this field is just as self-declared/spoofable as anything else in it): every real
// sendToContent()/sendDebug() call in inject.js sets source:"inject" and a numeric timestamp. A
// message missing that shape isn't one of the real bridge calls this file was built to translate.
function hasBridgeMarker(detail) {
  return !!detail && typeof detail === "object" && detail.source === "inject" && typeof detail.timestamp === "number";
}

// Pure translation: page-controlled CustomEvent detail -> canonical {event, properties} or null.
// Never throws on a malformed/hostile detail; never returns anything not already hardcoded here.
function translateBridgeMessage(detail) {
  if (!hasBridgeMarker(detail)) return null;
  const action = typeof detail.action === "string" ? detail.action : null;
  if (!action) return null;

  if (action === "navigation") {
    const data = detail.data;
    if (!data || typeof data !== "object") return null;
    const controller = typeof data.controller === "string" ? data.controller : null;
    const navType = typeof data.type === "string" ? data.type : null;
    // Only entering a screen counts as "opened" - popping back out is not a second action.
    if (navType !== "push" || !controller) return null;
    const mapped = NAVIGATION_FEATURE_MAP[controller];
    if (!mapped) return null;
    return { event: mapped.event, properties: mapped.feature ? { feature: mapped.feature } : undefined, dedupeKey: "nav:" + controller };
  }

  // autoCompleteSBC/autoCompleteSBCMulti are the Quick Complete / Complete Multiple Times
  // *request* - fired once per command, before EA has confirmed anything, and before this
  // codebase found the real per-challenge result data (see the SBC submit-outcome tracker
  // below). Reused for a second, unrelated feature too ("find an alternative player" slot-swap
  // preview, _cancelKey:"sbcSwap") - only the real solve/complete command (_cancelKey:"sbcSolve")
  // counts as a Quick Complete operation at all. This is deliberately NOT presented as
  // "N SBCs completed" - it is a technical "a command was issued" signal only.
  if (action === "autoCompleteSBC" || action === "autoCompleteSBCMulti") {
    const data = detail.data;
    if (!data || typeof data !== "object" || data._cancelKey !== "sbcSolve") return null;
    return { event: "sbc_quick_complete_started", properties: undefined, dedupeKey: "action:" + action };
  }

  const mappedEvent = ACTION_EVENT_MAP[action];
  if (!mappedEvent) return null;
  return { event: mappedEvent, properties: undefined, dedupeKey: "action:" + action };
}

// ---------------------------------------------------------------------------------------------
// SBC submit-outcome tracker.
//
// inject.js never exposes a structured "N challenges really submitted" result across the
// request/response bridge for autoCompleteSBC/autoCompleteSBCMulti - it dispatches the request
// (above) and the actual submission to EA (services.SBC.submitChallenge) happens entirely inside
// inject.js's own MAIN-world code, with no matching structured response event. The only real,
// per-challenge outcome data that reaches this isolated world at all is inject.js's own
// diagnostic "debug" messages from its retry-protected per-challenge submit loop
// (applySBCSetSolutions -> _submitChallengeWithRetry), used for BOTH a multi-challenge SBC set
// and a "Complete Multiple Times" repeat run - each real challenge submission (after inject.js's
// own internal retries have already resolved, so this is not re-logged per retry) produces
// exactly one of:
//   "✅ Auto-submit completed for challenge <id> (<n>/<total>)[ [<status>]]"
//   "Auto-submit failed for challenge <id>: <error>"
//
// This is the only real signal available without hand-editing inject.js - an already-minified
// bundle with no source in this repo, shared byte-for-byte with Desktop/Android/Bookmarklet, and
// out of scope to modify here. If inject.js's wording ever changes, these two patterns simply
// stop matching and no further counts are produced for that message - it fails toward
// undercounting nothing new, never toward inventing/overcounting a completion that didn't happen.
//
// Real per-user-operation results are only known once every challenge in the run has been
// attempted, so counts are aggregated across a short quiet window (or as soon as the message-
// reported total is reached, whichever is first) into ONE sbc_submitted (+ one feature_error for
// any failures) event per operation, instead of one HTTP request per challenge.
const SBC_SUBMIT_SUCCESS_RE = /^✅ Auto-submit completed for challenge (\S+) \((\d+)\/(\d+)\)/;
const SBC_SUBMIT_FAIL_RE = /^Auto-submit failed for challenge (\S+):/;
const SBC_SUBMIT_BURST_QUIET_MS = 4000; // no new matching debug message for this long => operation is over

let sbcBurst = null;

function newSbcBurst() {
  return { operationId: crypto.randomUUID(), successCount: 0, failCount: 0, expectedTotal: null, seenSuccessKeys: new Set(), timer: null };
}

function sendAnalyticsEvent(event, eventId, properties) {
  try {
    chrome.runtime.sendMessage({ type: "FUT_FORGE_ANALYTICS_EVENT", event, eventId, properties });
  } catch (e) {
    // Extension context can be invalidated (e.g. reload during dev) - never let that surface as a
    // page-visible error.
  }
}

function flushSbcBurst() {
  if (!sbcBurst) return;
  const burst = sbcBurst;
  sbcBurst = null;
  if (burst.timer) clearTimeout(burst.timer);
  // count = real completed units for THIS event only - never send a count=0 "completed" event;
  // zero real successes means no sbc_submitted event at all (0 completate, by omission).
  if (burst.successCount > 0) {
    sendAnalyticsEvent("sbc_submitted", `sbc-submitted-${burst.operationId}`, { count: burst.successCount });
  }
  if (burst.failCount > 0) {
    // Sanitized: no SBC/challenge name, no error text, no player data - a fixed feature label and
    // a real numeric count only.
    sendAnalyticsEvent("feature_error", `sbc-submit-error-${burst.operationId}`, { feature: "sbc_submit", count: burst.failCount });
  }
  // A "group completed" signal is only ever sent when the message-reported total was actually
  // reached - never inferred from a click, a timeout alone, or the number of challenges requested
  // (which this file never even sees). expectedTotal === 1 is a single Quick Complete, not a
  // group - only a genuine multi-challenge/repeat batch counts as a "group" here.
  if (burst.expectedTotal !== null && burst.expectedTotal > 1 && burst.successCount + burst.failCount === burst.expectedTotal) {
    sendAnalyticsEvent("sbc_group_completed", `sbc-group-${burst.operationId}`, undefined);
  }
}

function scheduleSbcFlush() {
  if (sbcBurst.timer) clearTimeout(sbcBurst.timer);
  sbcBurst.timer = setTimeout(flushSbcBurst, SBC_SUBMIT_BURST_QUIET_MS);
}

function handleSbcSubmitDebugMessage(message) {
  if (typeof message !== "string") return;

  const success = message.match(SBC_SUBMIT_SUCCESS_RE);
  if (success) {
    const [, challengeId, index, total] = success;
    if (!sbcBurst) sbcBurst = newSbcBurst();
    // (challengeId, index, total) uniquely identifies one real submission attempt within this
    // operation - re-delivery of the exact same debug event (e.g. a duplicated dispatch) is
    // ignored rather than double-counted. A genuinely distinct repeat/challenge always advances
    // index, so this never suppresses a real completion.
    const key = challengeId + "|" + index + "|" + total;
    if (!sbcBurst.seenSuccessKeys.has(key)) {
      sbcBurst.seenSuccessKeys.add(key);
      sbcBurst.successCount++;
    }
    const totalNum = Number(total);
    if (Number.isFinite(totalNum)) sbcBurst.expectedTotal = totalNum;
    scheduleSbcFlush();
    if (sbcBurst.expectedTotal !== null && sbcBurst.successCount + sbcBurst.failCount >= sbcBurst.expectedTotal) flushSbcBurst();
    return;
  }

  const fail = message.match(SBC_SUBMIT_FAIL_RE);
  if (fail) {
    if (!sbcBurst) sbcBurst = newSbcBurst();
    sbcBurst.failCount++;
    scheduleSbcFlush();
    if (sbcBurst.expectedTotal !== null && sbcBurst.successCount + sbcBurst.failCount >= sbcBurst.expectedTotal) flushSbcBurst();
  }
}

function handleBridgeMessage(customEvent) {
  try {
    const detail = customEvent && customEvent.detail;
    if (!hasBridgeMarker(detail)) return;

    if (detail.action === "debug") {
      handleSbcSubmitDebugMessage(detail.data && typeof detail.data === "object" ? detail.data.message : undefined);
      return;
    }

    const translated = translateBridgeMessage(detail);
    if (!translated) return;
    if (!shouldForward(translated.dedupeKey, Date.now())) return;
    sendAnalyticsEvent(translated.event, undefined, translated.properties);
  } catch (e) {
    // Extension context can be invalidated (e.g. reload during dev) - never let that surface as a
    // page-visible error, and never let a bridge failure affect the page itself.
  }
}

try {
  chrome.runtime.sendMessage({ type: "FUT_FORGE_EA_TAB_READY" });
} catch (e) {
  // Extension context can be invalidated (e.g. reload during dev) - never
  // let that surface as a page-visible error.
}

document.addEventListener("futforge-message", handleBridgeMessage);

// Exports exist only for tests to exercise the pure translation/debounce/aggregation logic
// directly with a mocked chrome.runtime. Inert for the real content script: this file is loaded
// as a classic (non-module) script per manifest.json, so an unused top-level export has no
// runtime effect.

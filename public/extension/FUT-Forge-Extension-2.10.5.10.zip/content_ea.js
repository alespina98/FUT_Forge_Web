// content_ea.js — isolated-world content script on the EA FC Ultimate Team
// Web App. Purely a presence beacon: tells background.js this tab exists and
// is a real EA club page, so background knows a valid capture target is
// open. Does NOT read cookies, storage, DOM content, or perform any capture
// itself - the actual Club Capture logic lives in page_ea.js (MAIN world),
// injected on demand by background.js only when a sync is requested.
//
// SECURITY: this script touches nothing on the page. It sends exactly one
// message type, with no page data in it.
try {
  chrome.runtime.sendMessage({ type: "FUT_FORGE_EA_TAB_READY" });
} catch (e) {
  // Extension context can be invalidated (e.g. reload during dev) - never
  // let that surface as a page-visible error.
}
